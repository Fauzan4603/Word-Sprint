using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class script : MonoBehaviour
{
    public GameObject Home;
    public GameObject Materi;

    // Start is called before the first frame update
    void Start()
    {
        Home.SetActive(true);
        Materi.SetActive(false);
    }

    public void infobtnClicked()
    {
        Home.SetActive(false);
        Materi.SetActive(true);
    }
    public void backbtnClicked(){
        Home.SetActive(true);
        Materi.SetActive(false);
    }

}
//     // Update is called once per frame
//     void Update()
//     {
        
//     }
// }
